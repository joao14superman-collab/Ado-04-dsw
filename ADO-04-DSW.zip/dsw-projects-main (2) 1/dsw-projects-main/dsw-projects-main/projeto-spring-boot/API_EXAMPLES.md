# API Examples - Exemplos de Requisições

## Autenticação

### Login via Formulário HTML
```
POST /login
Content-Type: application/x-www-form-urlencoded

username=admin&password=admin123
```

### Registrar Novo Administrador
```
POST /auth/register
Content-Type: application/x-www-form-urlencoded

username=novo_admin&password=senha123&role=ROLE_ADMIN
```

---

## Endpoints Públicos (Sem Autenticação)

### 1. Listar Cursos Ativos
```bash
curl -X GET http://localhost:8080/api/courses/active
```

**Resposta (200 OK):**
```json
[
  {
    "id": 1,
    "name": "Java Avançado",
    "description": "Aprenda os conceitos avançados da linguagem Java",
    "category": "Programação",
    "instructor": "João Silva",
    "workload": 40,
    "active": true
  }
]
```

### 2. Obter Curso por ID
```bash
curl -X GET http://localhost:8080/api/courses/1
```

**Resposta (200 OK):**
```json
{
  "id": 1,
  "name": "Java Avançado",
  "description": "Aprenda os conceitos avançados da linguagem Java",
  "category": "Programação",
  "instructor": "João Silva",
  "workload": 40,
  "active": true
}
```

### 3. Buscar Cursos por Nome
```bash
curl -X GET "http://localhost:8080/api/courses/search/by-name?name=Java"
```

### 4. Buscar Cursos por Categoria
```bash
curl -X GET "http://localhost:8080/api/courses/search/by-category?category=Programação"
```

---

## Endpoints Protegidos (Com Autenticação)

### 1. Listar Todos os Cursos (incluindo inativos)
```bash
curl -X GET http://localhost:8080/api/courses \
  -H "Authorization: Basic YWRtaW46YWRtaW4xMjM=" \
  -H "Content-Type: application/json"
```

**Resposta (200 OK):**
```json
[
  {
    "id": 1,
    "name": "Java Avançado",
    "description": "Aprenda os conceitos avançados",
    "category": "Programação",
    "instructor": "João Silva",
    "workload": 40,
    "active": true
  },
  {
    "id": 2,
    "name": "Spring Boot Masterclass",
    "description": "Desenvolvimento com Spring Boot",
    "category": "Programação",
    "instructor": "Maria Santos",
    "workload": 50,
    "active": true
  }
]
```

### 2. Criar Novo Curso
```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Authorization: Basic YWRtaW46YWRtaW4xMjM=" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Python Avançado",
    "description": "Aprenda Python com foco em dados",
    "category": "Programação",
    "instructor": "Dr. Tech",
    "workload": 35,
    "active": true
  }'
```

**Resposta (200 OK):**
```json
{
  "id": 6,
  "name": "Python Avançado",
  "description": "Aprenda Python com foco em dados",
  "category": "Programação",
  "instructor": "Dr. Tech",
  "workload": 35,
  "active": true
}
```

### 3. Atualizar Curso Existente
```bash
curl -X PUT http://localhost:8080/api/courses/1 \
  -H "Authorization: Basic YWRtaW46YWRtaW4xMjM=" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Java Avançado - Atualizado",
    "description": "Aprenda os conceitos mais avançados",
    "category": "Programação",
    "instructor": "João Silva - Senior",
    "workload": 45,
    "active": true
  }'
```

**Resposta (200 OK):**
```json
{
  "id": 1,
  "name": "Java Avançado - Atualizado",
  "description": "Aprenda os conceitos mais avançados",
  "category": "Programação",
  "instructor": "João Silva - Senior",
  "workload": 45,
  "active": true
}
```

### 4. Deletar Curso
```bash
curl -X DELETE http://localhost:8080/api/courses/6 \
  -H "Authorization: Basic YWRtaW46YWRtaW4xMjM="
```

**Resposta (204 No Content):**
```
(sem corpo na resposta)
```

---

## Usando Postman

### Configurar Autenticação Básica

1. Abra uma nova requisição no Postman
2. Vá para a aba "Authorization"
3. Selecione "Basic Auth"
4. Entre com:
   - Username: `admin`
   - Password: `admin123`
5. A autenticação será adicionada automaticamente aos headers

### Exemplo de Requisição POST
```
Method: POST
URL: http://localhost:8080/api/courses

Headers:
Authorization: Basic YWRtaW46YWRtaW4xMjM=
Content-Type: application/json

Body (raw JSON):
{
  "name": "TypeScript Avançado",
  "description": "Desenvolvimento web com TypeScript",
  "category": "Programação",
  "instructor": "Frontend Master",
  "workload": 30,
  "active": true
}
```

---

## Codificação da Autenticação Básica

Para gerar o header de autenticação básica:
- Formato: `username:password` (ex: `admin:admin123`)
- Codificar em Base64: `YWRtaW46YWRtaW4xMjM=`
- Header: `Authorization: Basic YWRtaW46YWRtaW4xMjM=`

**Geradores online:**
- https://www.base64encode.org/
- https://www.base64decode.org/

---

## Códigos de Status HTTP

| Código | Significado |
|--------|-------------|
| 200 | OK - Requisição bem-sucedida |
| 204 | No Content - Deletado com sucesso |
| 400 | Bad Request - Dados inválidos |
| 401 | Unauthorized - Sem autenticação |
| 403 | Forbidden - Sem autorização |
| 404 | Not Found - Recurso não encontrado |
| 500 | Internal Server Error - Erro no servidor |

---

## Validações de Entrada

### Criar/Atualizar Curso

```json
{
  "name": "String (obrigatório, não vazio)",
  "description": "String (obrigatório, não vazio)",
  "category": "String (obrigatório)",
  "instructor": "String (obrigatório)",
  "workload": "Número inteiro (obrigatório, > 0)",
  "active": "Boolean (opcional, padrão: true)"
}
```

### Mensagens de Erro de Validação

```json
{
  "timestamp": "2025-11-26T15:30:00.000+00:00",
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "details": {
    "name": "O nome do curso é obrigatório",
    "workload": "A carga horária deve ser maior que zero"
  }
}
```

---

**Autor**: Sistema de Gestão de Cursos - ADO 4  
**Data**: Novembro de 2025
