#!/usr/bin/env pwsh
# Script para iniciar o Sistema de Gestão de Cursos

Write-Host ""
Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "Sistema de Gestao de Cursos" -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan
Write-Host ""

# Set JAVA_HOME
$env:JAVA_HOME = "C:\Program Files\Java\jdk1.8.0_202"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"

Write-Host "JAVA_HOME: $env:JAVA_HOME" -ForegroundColor Yellow

# Verify Java
Write-Host "Verificando Java..." -ForegroundColor Yellow
$javaVersion = & cmd /c "java -version" 2>&1
Write-Host $javaVersion

# Change to script directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Write-Host ""
Write-Host "Compilando projeto..." -ForegroundColor Yellow
& .\mvnw.cmd clean compile -q

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "ERRO na compilacao!" -ForegroundColor Red
    Write-Host "Pressione uma tecla para sair..."
    $null = Read-Host
    exit 1
}

Write-Host ""
Write-Host "Iniciando aplicacao..." -ForegroundColor Green
Write-Host ""
Write-Host "Acesse no navegador: http://localhost:8080" -ForegroundColor Green
Write-Host ""
Write-Host "Credenciais de login:" -ForegroundColor Green
Write-Host "  Usuario: admin" -ForegroundColor Green
Write-Host "  Senha:   admin123" -ForegroundColor Green
Write-Host ""
Write-Host "Pressione CTRL+C para parar a aplicacao" -ForegroundColor Yellow
Write-Host ""

& .\mvnw.cmd spring-boot:run
