# 🚀 Guia de Deploy - Sistema de Gestão de Cursos

## Ambiente Local (Desenvolvimento)

### Pré-requisitos
- Java 17 ou superior
- Maven 3.8.1+
- Git (opcional)

### Passos

```bash
# 1. Clonar ou extrair o projeto
git clone <URL> # ou extrair ZIP

# 2. Navegar para o diretório
cd carstore-spring-boot

# 3. Compilar
mvn clean install

# 4. Executar
mvn spring-boot:run
```

**Acesso**: `http://localhost:8080`

---

## Build para Produção

### Criar arquivo JAR executável

```bash
# Compilar e criar JAR
mvn clean package

# Arquivo gerado em:
# target/carstore-0.0.1-SNAPSHOT.jar
```

### Executar o JAR

```bash
java -jar target/carstore-0.0.1-SNAPSHOT.jar
```

---

## Configuração de Banco de Dados

### Para Desenvolvimento (H2 Atual)
```properties
spring.datasource.url=jdbc:h2:~/schooldb
spring.datasource.driverClassName=org.h2.Driver
spring.jpa.hibernate.ddl-auto=create-drop
spring.h2.console.enabled=true
```

### Para Produção (PostgreSQL Exemplo)

#### 1. Adicionar dependência no `pom.xml`
```xml
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
</dependency>
```

#### 2. Criar arquivo `application-prod.properties`
```properties
spring.datasource.url=jdbc:postgresql://hostname:5432/coursedb
spring.datasource.username=user
spring.datasource.password=password
spring.datasource.driverClassName=org.postgresql.Driver

spring.jpa.database-platform=org.hibernate.dialect.PostgreSQL10Dialect
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=false

# Segurança
server.servlet.session.cookie.secure=true
server.servlet.session.cookie.http-only=true
server.servlet.session.timeout=30m
```

#### 3. Executar com perfil prod
```bash
java -jar carstore-0.0.1-SNAPSHOT.jar --spring.profiles.active=prod
```

---

## Segurança para Produção

### 1. Alterar Senha Padrão

Editar `DataLoader.java`:
```java
User admin = new User("admin", "SenhaSeguraAqui123!", "ROLE_ADMIN");
```

### 2. Habilitar HTTPS

Gerar certificado:
```bash
keytool -genkey -alias tomcat -storetype PKCS12 -keyalg RSA \
  -keysize 2048 -keystore keystore.p12 -validity 3650
```

Configurar `application.properties`:
```properties
server.ssl.key-store=keystore.p12
server.ssl.key-store-password=sua-senha
server.ssl.key-store-type=PKCS12
server.ssl.key-alias=tomcat
```

### 3. Disabilitar Console H2

```properties
spring.h2.console.enabled=false
```

### 4. Configurar CORS

Editar `SecurityConfig.java`:
```java
@Bean
public WebMvcConfigurer corsConfigurer() {
    return new WebMvcConfigurer() {
        @Override
        public void addCorsMappings(CorsRegistry registry) {
            registry.addMapping("/api/**")
                .allowedOrigins("https://seu-dominio.com")
                .allowedMethods("GET", "POST", "PUT", "DELETE")
                .allowCredentials(true)
                .maxAge(3600);
        }
    };
}
```

---

## Deploy em Docker

### 1. Criar `Dockerfile`

```dockerfile
FROM openjdk:17-jdk-slim

WORKDIR /app

COPY target/carstore-0.0.1-SNAPSHOT.jar application.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "application.jar"]
```

### 2. Criar `docker-compose.yml`

```yaml
version: '3'
services:
  app:
    build: .
    ports:
      - "8080:8080"
    environment:
      - SPRING_DATASOURCE_URL=jdbc:postgresql://db:5432/coursedb
      - SPRING_DATASOURCE_USERNAME=postgres
      - SPRING_DATASOURCE_PASSWORD=postgres
      - SPRING_PROFILES_ACTIVE=prod
    depends_on:
      - db
  
  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=coursedb
      - POSTGRES_PASSWORD=postgres
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

### 3. Build e Run

```bash
# Build da imagem
docker-compose build

# Iniciar contêiner
docker-compose up -d

# Parar contêiner
docker-compose down
```

---

## Deploy em Heroku

### 1. Instalar Heroku CLI

```bash
# macOS
brew tap heroku/brew && brew install heroku

# Windows
# Download em https://cli-assets.heroku.com/heroku-windows-x86_64.exe
```

### 2. Fazer Login

```bash
heroku login
```

### 3. Criar Aplicação

```bash
heroku create seu-app-name
```

### 4. Adicionar Banco de Dados

```bash
heroku addons:create heroku-postgresql:hobby-dev -a seu-app-name
```

### 5. Deploy

```bash
# Commit no Git
git add .
git commit -m "Deploy em Heroku"

# Push para Heroku
git push heroku main
```

### 6. Verificar Logs

```bash
heroku logs --tail
```

---

## Deploy em AWS

### Usar Elastic Beanstalk

```bash
# 1. Instalar AWS CLI
aws configure

# 2. Instalar EB CLI
pip install awsebcli

# 3. Inicializar
eb init -p "Java 17 running on 64bit Amazon Linux 2" seu-app

# 4. Criar ambiente
eb create seu-ambiente

# 5. Deploy
eb deploy

# 6. Abrir aplicação
eb open
```

---

## Monitoramento em Produção

### Adicionar Actuator

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

Acessar endpoints:
- `http://seu-dominio.com/actuator/health` - Status
- `http://seu-dominio.com/actuator/metrics` - Métricas

---

## Backup do Banco de Dados

### PostgreSQL

```bash
# Backup
pg_dump -U user -d coursedb -f backup.sql

# Restore
psql -U user -d coursedb -f backup.sql
```

### H2

```bash
# O arquivo está em ~/schooldb.h2.db
cp ~/schooldb.h2.db ~/backup/schooldb.h2.db.backup
```

---

## Variáveis de Ambiente

Usar variáveis de ambiente para configurações sensíveis:

```bash
# Exportar variáveis
export DB_URL=jdbc:postgresql://localhost/coursedb
export DB_USER=postgres
export DB_PASSWORD=senha

# Ou no arquivo .env
DB_URL=jdbc:postgresql://localhost/coursedb
DB_USER=postgres
DB_PASSWORD=senha
```

Referenciar em `application.properties`:
```properties
spring.datasource.url=${DB_URL}
spring.datasource.username=${DB_USER}
spring.datasource.password=${DB_PASSWORD}
```

---

## Checklist de Deploy

### Antes de Deployar
- [ ] Testar em ambiente local
- [ ] Verificar todas funcionalidades
- [ ] Alterar senhas padrão
- [ ] Configurar banco de dados de produção
- [ ] Habilitar HTTPS
- [ ] Disabilitar console H2
- [ ] Revisar logs
- [ ] Fazer backup dos dados

### Depois de Deployar
- [ ] Testar URLs principais
- [ ] Verificar autenticação
- [ ] Testar CRUD de cursos
- [ ] Monitorar performance
- [ ] Configurar alertas
- [ ] Documentar credenciais (em local seguro)
- [ ] Fazer backup regular

---

## Troubleshooting

### Problema: Porta 8080 em uso
```bash
# Linux/Mac
lsof -i :8080
kill -9 <PID>

# Windows
netstat -ano | findstr :8080
taskkill /PID <PID> /F
```

### Problema: Erro de memória
```bash
java -Xmx512m -jar carstore-0.0.1-SNAPSHOT.jar
```

### Problema: Conexão com banco de dados
```bash
# Verificar URL
# Verificar credentials
# Verificar firewall
# Verificar status do banco
```

---

## Performance Tuning

### JVM Tuning
```bash
java -Xms256m -Xmx512m \
     -XX:+UseG1GC \
     -XX:MaxGCPauseMillis=200 \
     -jar carstore-0.0.1-SNAPSHOT.jar
```

### Connection Pool
```properties
spring.datasource.hikari.maximum-pool-size=20
spring.datasource.hikari.minimum-idle=5
```

---

## Suporte ao Deploy

Documentação oficial:
- Spring Boot: https://spring.io/guides/gs/spring-boot/
- Heroku: https://devcenter.heroku.com/
- AWS Elastic Beanstalk: https://docs.aws.amazon.com/elasticbeanstalk/
- Docker: https://docs.docker.com/

---

**Data**: 26 de Novembro de 2025  
**Versão**: 1.0.0
