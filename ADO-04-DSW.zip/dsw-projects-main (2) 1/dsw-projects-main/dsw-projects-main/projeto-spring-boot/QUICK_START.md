# 🎓 SISTEMA DE GESTÃO DE CURSOS - MANUAL RÁPIDO

## O Que Foi Criado?

Um **sistema web profissional** para gerenciar cursos em escolas, desenvolvido com **Spring Boot**.

---

## 🚀 Como Usar em 3 Passos

### Passo 1: Baixar e Preparar
```bash
# Abrir terminal/PowerShell na pasta do projeto
cd carstore-spring-boot
```

### Passo 2: Compilar
```bash
mvn clean install
```

### Passo 3: Executar
```bash
mvn spring-boot:run
```

**Pronto!** Acesse: `http://localhost:8080`

---

## 📌 O Que o Sistema Faz?

### Para Visitantes (Público)
✅ Ver todos os cursos disponíveis  
✅ Buscar por nome  
✅ Filtrar por categoria  
✅ Ver detalhes completos  

### Para Administradores (Logado)
✅ Criar novos cursos  
✅ Editar cursos existentes  
✅ Deletar cursos  
✅ Ver estatísticas no dashboard  

---

## 🔐 Fazer Login

**Na primeira vez:**

1. Clique em "Administrador" ou vá para `/login`
2. Digite:
   - **Usuário**: `admin`
   - **Senha**: `admin123`
3. Será direcionado ao Dashboard

**Criar novo administrador:**

Clique em "Registre-se aqui" e preencha um usuário novo.

---

## 📍 Principais Páginas

| Página | URL | Descrição |
|--------|-----|-----------|
| Home | `/` | Página inicial |
| Cursos (Público) | `/courses/public` | Lista pública |
| Buscar | `/courses/search` | Buscar cursos |
| Login | `/login` | Autenticação |
| Dashboard | `/admin/dashboard` | Painel admin |
| Gerenciar | `/courses` | CRUD admin |
| Novo Curso | `/courses/new` | Criar curso |

---

## 💾 Banco de Dados

O sistema usa **H2 Database** - não precisa instalar nada, funciona automaticamente!

Dados iniciais:
- 1 usuário admin (admin/admin123)
- 5 cursos de exemplo

---

## 🔌 API (Para Desenvolvedores)

Exemplos de requisições:

### Listar cursos (público)
```bash
curl http://localhost:8080/api/courses/active
```

### Criar curso (requer login)
```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Python",
    "description": "Curso de Python",
    "category": "Programação",
    "instructor": "João",
    "workload": 30
  }'
```

Mais exemplos em: `API_EXAMPLES.md`

---

## 📁 Arquivos Importantes

- **README.md** - Guia completo
- **API_EXAMPLES.md** - Exemplos da API
- **DEPLOY_GUIDE.md** - Como colocar em produção
- **pom.xml** - Dependências do projeto

---

## 🛠️ Tecnologias Usadas

- **Java 17** - Linguagem
- **Spring Boot 3.5** - Framework
- **Thymeleaf** - Templates HTML
- **Spring Security** - Autenticação
- **H2 Database** - Banco de dados
- **Bootstrap 5** - Estilo/Design
- **Maven** - Construção

---

## ✅ Tudo Funciona?

Todos os requisitos da ADO 4 foram implementados:

✅ Cadastro de cursos  
✅ Área admin com CRUD completo  
✅ Área pública para consultas  
✅ Controllers web e API  
✅ Thymeleaf templates  
✅ Validação de dados  
✅ Spring Data JPA  
✅ Spring Security  
✅ H2 Database  
✅ Documentação  

---

## 📱 Responsivo?

Sim! O sistema funciona perfeitamente em:
- Computadores
- Tablets
- Celulares

---

## 🚨 Problemas?

### Porta 8080 em uso
```bash
# Matar processo
netstat -ano | findstr :8080
taskkill /PID <PID> /F
```

### Recompilação rápida
```bash
mvn clean compile
```

### Limpar tudo
```bash
mvn clean
```

---

## 📚 Mais Informações?

Consulte os arquivos de documentação:

1. **README.md** - Guia completo
2. **PROJECT_OVERVIEW.md** - Visão geral
3. **IMPLEMENTATION_STATUS.md** - Status detalhado
4. **DELIVERY_SUMMARY.md** - Resumo da entrega
5. **API_EXAMPLES.md** - Exemplos de API
6. **DEPLOY_GUIDE.md** - Como fazer deploy

---

## 🎯 Próximas Ações

1. ✅ **Testar** - Acesse o sistema e experimente
2. ✅ **Explorar** - Cadastre novos cursos
3. ✅ **Consultar** - Use a API REST
4. ✅ **Documentar** - Revise a documentação
5. ✅ **Entregar** - Suba para GitHub

---

## 📝 Dados de Teste Inclusos

**Usuário:**
- admin / admin123

**Cursos (carregados automaticamente):**
1. Java Avançado
2. Spring Boot Masterclass
3. Design UX/UI
4. Banco de Dados SQL
5. Docker e Kubernetes

---

## ✨ Features Extras

- Dashboard com estatísticas
- Busca e filtro avançado
- Design moderno e bonito
- Senhas criptografadas
- Validação completa
- Tratamento de erros
- API REST completa

---

## 🎓 Conclusão

**O sistema está 100% funcional e pronto para entrega!**

Todos os requisitos da ADO 4 foram implementados com qualidade profissional.

---

**Criado**: 26 de Novembro de 2025  
**Versão**: 1.0.0  
**Status**: ✅ COMPLETO

---

*Para dúvidas, consulte a documentação completa nos arquivos .md*
