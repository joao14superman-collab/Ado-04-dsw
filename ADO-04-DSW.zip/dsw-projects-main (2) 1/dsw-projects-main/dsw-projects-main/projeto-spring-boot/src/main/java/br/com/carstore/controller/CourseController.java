package br.com.carstore.controller;

import br.com.carstore.model.Course;
import br.com.carstore.service.CourseService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    // ============ Public Routes (without authentication) ============

    @GetMapping("/public")
    public String listPublicCourses(Model model) {
        List<Course> courses = courseService.getActiveCourses();
        model.addAttribute("courses", courses);
        return "courses/public-list";
    }

    @GetMapping("/search")
    public String searchCourses(@RequestParam(required = false) String name,
                                @RequestParam(required = false) String category,
                                Model model) {
        List<Course> courses;
        if (name != null && !name.isEmpty()) {
            courses = courseService.searchByName(name);
        } else if (category != null && !category.isEmpty()) {
            courses = courseService.searchByCategory(category);
        } else {
            courses = courseService.getActiveCourses();
        }
        model.addAttribute("courses", courses);
        model.addAttribute("searchName", name);
        model.addAttribute("searchCategory", category);
        return "courses/search-results";
    }

    @GetMapping("/{id}/details")
    public String viewCourseDetails(@PathVariable Long id, Model model) {
        Optional<Course> course = courseService.getCourseById(id);
        if (course.isPresent()) {
            model.addAttribute("course", course.get());
            return "courses/public-details";
        }
        return "redirect:/courses/public";
    }

    // ============ Admin Routes (with authentication) ============

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public String listCourses(Model model) {
        List<Course> courses = courseService.getAllCourses();
        model.addAttribute("courses", courses);
        return "courses/list";
    }

    @GetMapping("/new")
    @PreAuthorize("hasRole('ADMIN')")
    public String createForm(Model model) {
        model.addAttribute("course", new Course());
        return "courses/form";
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public String saveCourse(@Valid Course course, BindingResult result) {
        if (result.hasErrors()) {
            return "courses/form";
        }
        courseService.saveCourse(course);
        return "redirect:/courses";
    }

    @GetMapping("/{id}/edit")
    @PreAuthorize("hasRole('ADMIN')")
    public String editForm(@PathVariable Long id, Model model) {
        Optional<Course> course = courseService.getCourseById(id);
        if (course.isPresent()) {
            model.addAttribute("course", course.get());
            return "courses/form";
        }
        return "redirect:/courses";
    }

    @PostMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String updateCourse(@PathVariable Long id, @Valid Course course, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("course", course);
            return "courses/form";
        }
        courseService.updateCourse(id, course);
        return "redirect:/courses";
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return "redirect:/courses";
    }

    @GetMapping("/{id}/delete")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteGet(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return "redirect:/courses";
    }
}
