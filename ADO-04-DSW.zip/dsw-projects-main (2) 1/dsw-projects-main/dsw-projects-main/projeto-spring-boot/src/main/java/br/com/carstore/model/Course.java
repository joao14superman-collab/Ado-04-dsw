package br.com.carstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "O nome do curso é obrigatório")
    @Column(nullable = false)
    private String name;

    @NotBlank(message = "A descrição é obrigatória")
    @Column(columnDefinition = "TEXT")
    private String description;

    @NotNull(message = "A carga horária é obrigatória")
    @Positive(message = "A carga horária deve ser maior que zero")
    @Column(nullable = false)
    private Integer workload;

    @NotBlank(message = "O instrutor é obrigatório")
    @Column(nullable = false)
    private String instructor;

    @NotNull(message = "A categoria é obrigatória")
    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private Boolean active = true;

    // Constructors
    public Course() {
    }

    public Course(String name, String description, Integer workload, String instructor, String category) {
        this.name = name;
        this.description = description;
        this.workload = workload;
        this.instructor = instructor;
        this.category = category;
        this.active = true;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getWorkload() {
        return workload;
    }

    public void setWorkload(Integer workload) {
        this.workload = workload;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", workload=" + workload +
                ", instructor='" + instructor + '\'' +
                ", category='" + category + '\'' +
                ", active=" + active +
                '}';
    }
}
