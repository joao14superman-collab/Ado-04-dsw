package br.com.carstore.runner;

import br.com.carstore.model.Course;
import br.com.carstore.model.User;
import br.com.carstore.repository.CourseRepository;
import br.com.carstore.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public void run(String... args) throws Exception {
        // Criar usuário de teste
        if (!userService.userExists("admin")) {
            User admin = new User("admin", "admin123", "ROLE_ADMIN");
            userService.saveUser(admin);
            System.out.println("✓ Usuário admin criado com sucesso!");
        }

        // Criar cursos de teste
        if (courseRepository.count() == 0) {
            Course course1 = new Course(
                    "Java Avançado",
                    "Aprenda os conceitos avançados da linguagem Java, incluindo streams, lambdas e programação funcional.",
                    40,
                    "João Silva",
                    "Programação"
            );

            Course course2 = new Course(
                    "Spring Boot Masterclass",
                    "Desenvolvimento completo de aplicações web com Spring Boot, incluindo autenticação e banco de dados.",
                    50,
                    "Maria Santos",
                    "Programação"
            );

            Course course3 = new Course(
                    "Design UX/UI",
                    "Aprenda os princípios fundamentais de design, prototipagem e experiência do usuário.",
                    30,
                    "Carlos Mendes",
                    "Design"
            );

            Course course4 = new Course(
                    "Banco de Dados SQL",
                    "Dominando SQL, queries complexas, índices e otimização de banco de dados.",
                    35,
                    "Ana Costa",
                    "Banco de Dados"
            );

            Course course5 = new Course(
                    "Docker e Kubernetes",
                    "Containerização com Docker e orquestração com Kubernetes para aplicações em produção.",
                    45,
                    "Pedro Oliveira",
                    "DevOps"
            );

            courseRepository.save(course1);
            courseRepository.save(course2);
            courseRepository.save(course3);
            courseRepository.save(course4);
            courseRepository.save(course5);

            System.out.println("✓ 5 cursos de teste criados com sucesso!");
        }
    }
}
