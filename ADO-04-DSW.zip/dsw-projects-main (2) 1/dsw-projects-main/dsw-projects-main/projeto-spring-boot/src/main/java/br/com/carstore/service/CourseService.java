package br.com.carstore.service;

import br.com.carstore.model.Course;
import br.com.carstore.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public List<Course> getActiveCourses() {
        return courseRepository.findByActive(true);
    }

    public Optional<Course> getCourseById(Long id) {
        return courseRepository.findById(id);
    }

    public Course saveCourse(Course course) {
        return courseRepository.save(course);
    }

    public Course updateCourse(Long id, Course course) {
        Optional<Course> existingCourse = courseRepository.findById(id);
        if (existingCourse.isPresent()) {
            Course c = existingCourse.get();
            c.setName(course.getName());
            c.setDescription(course.getDescription());
            c.setWorkload(course.getWorkload());
            c.setInstructor(course.getInstructor());
            c.setCategory(course.getCategory());
            c.setActive(course.getActive());
            return courseRepository.save(c);
        }
        throw new RuntimeException("Curso não encontrado");
    }

    public void deleteCourse(Long id) {
        courseRepository.deleteById(id);
    }

    public List<Course> searchByCategory(String category) {
        return courseRepository.findByCategory(category);
    }

    public List<Course> searchByName(String name) {
        return courseRepository.findByNameContainingIgnoreCase(name);
    }
}
