package br.com.carstore.controller;

import br.com.carstore.model.User;
import br.com.carstore.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String login() {
        return "auth/login";
    }

    @GetMapping("/register")
    public String register() {
        return "auth/register";
    }

    @PostMapping("/register")
    public String registerUser(User user) {
        if (userService.userExists(user.getUsername())) {
            return "redirect:/auth/register?error=Usuário já existe";
        }
        user.setRole("ROLE_ADMIN");
        userService.saveUser(user);
        return "redirect:/auth/login?success=Usuário registrado com sucesso";
    }
}
